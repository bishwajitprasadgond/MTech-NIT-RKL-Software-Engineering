
import cute.Cute;
import java.util.Scanner;
public class Calculator {
  public static void main(String[] args) {
   // Scanner input = new Scanner(System.in);

    System.out.print("Enter first number: ");
    float num1 = Cute.input.Integer();

    System.out.print("Enter second number: ");
    float num2 = Cute.input.Integer();

    System.out.println("\nChoose an operation:\n");
    System.out.println("\t1. Addition");
    System.out.println("\t2. Subtraction");
    System.out.println("\t3. Multiplication");
    System.out.println("\t4. Division");
    System.out.print("\nEnter your choice (1-4): ");
    int choice = Cute.input.Integer();

    float result = 0.0f;
    switch (choice) {
      case 1:
        result = num1 + num2;
        break;
      case 2:
        result = num1 - num2;
        break;
      case 3:
        result = num1 * num2;
        break;
      case 4:
        if (num2 == 0) {
          System.out.println("Error: Division by zero.");
          return;
        }
        result = num1 / num2;
        break;
      default:
        System.out.println("Invalid choice.");
        return;
    }

    System.out.println("Result: " + result);
  }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=10000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=0
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=false
