package tests;

/**
 *  .
 * User: ksen
 * Date: Oct 27, 2005
 * Time: 7:41:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class HelloWorld extends Thread{
    public static void main(String[] args) {
        String s = new String("Hello World!");
        
    }
}
