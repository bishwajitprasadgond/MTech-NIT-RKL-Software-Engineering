package cute.dcute;

/**
 *  .
 * User: ksen
 * Date: Oct 9, 2005
 * Time: 6:37:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class Pair {
    public int x;
    public int y;
}
