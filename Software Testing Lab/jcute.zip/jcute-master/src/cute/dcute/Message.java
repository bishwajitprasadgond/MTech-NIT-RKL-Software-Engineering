package cute.dcute;

import java.util.IdentityHashMap;

/**
 *  .
 * User: ksen
 * Date: Oct 9, 2005
 * Time: 2:57:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class Message {
    public IdentityHashMap vc;
}
