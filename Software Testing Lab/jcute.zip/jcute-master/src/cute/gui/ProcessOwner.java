package cute.gui;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Dec 22, 2005
 * Time: 6:28:26 PM
 */
public interface ProcessOwner {
    public void setProcess(Process proc);
}
