package cute.gui;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Dec 22, 2005
 * Time: 10:51:55 PM
 */
public class DefaultGuiControllerMask implements GuiControllerMask {
    public void updateRunNumberListModel(String s, int err) {
    }
}
