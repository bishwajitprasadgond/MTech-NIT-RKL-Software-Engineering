package cute.gui;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Dec 22, 2005
 * Time: 8:07:42 PM
 */
public interface GuiControllerMask {
    public void updateRunNumberListModel(String s,int err);
}
