package cute.gui;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Dec 22, 2005
 * Time: 7:23:36 PM
 */
public interface MessageLogger {
    void ask(String s);
}
