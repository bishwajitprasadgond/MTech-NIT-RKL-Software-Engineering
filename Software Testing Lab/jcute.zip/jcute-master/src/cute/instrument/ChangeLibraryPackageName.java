package cute.instrument;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Jun 25, 2006
 * Time: 11:35:15 AM
 */
public class ChangeLibraryPackageName {
    
}
