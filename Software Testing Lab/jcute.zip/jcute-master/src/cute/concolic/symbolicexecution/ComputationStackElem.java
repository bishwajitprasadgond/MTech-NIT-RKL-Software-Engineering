package cute.concolic.symbolicexecution;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class ComputationStackElem {
    public long address;
    public double value;
    public long valueLong;
}
