package cute.concolic;

/**
 *  .
 * User: ksen
 * Date: Oct 26, 2005
 * Time: 4:22:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssumeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5768990918549982072L;

	/**
	 * 
	 */
}
