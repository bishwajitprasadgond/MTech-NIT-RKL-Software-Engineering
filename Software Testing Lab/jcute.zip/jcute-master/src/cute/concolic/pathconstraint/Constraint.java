package cute.concolic.pathconstraint;

import java.io.PrintWriter;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public interface Constraint {
    public void printConstraint(PrintWriter out);
}
