package cute.concolic.symbolicstate;

import java.io.PrintWriter;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class Expression {
    public void printExpression(PrintWriter out){

    }
}
