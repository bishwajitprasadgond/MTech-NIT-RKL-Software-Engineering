package cute.concolic.logging;

import java.io.PrintWriter;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Jun 28, 2006
 * Time: 10:53:38 AM
 */
public interface Printable {
    public void print(PrintWriter out);
}
