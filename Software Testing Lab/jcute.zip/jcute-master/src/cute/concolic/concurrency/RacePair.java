package cute.concolic.concurrency;

import cute.concolic.logging.RaceLog;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Jan 2, 2006
 * Time: 1:37:14 PM
 */
public class RacePair {
    public RaceLog rl1;
    public RaceLog rl2;
}
