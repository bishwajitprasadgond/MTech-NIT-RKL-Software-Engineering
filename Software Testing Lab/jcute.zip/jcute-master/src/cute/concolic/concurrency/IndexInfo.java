package cute.concolic.concurrency;

/**
 * Created by IntelliJ IDEA.
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Dec 26, 2005
 * Time: 8:46:36 PM
 */
public class IndexInfo {
    public int index;
}
