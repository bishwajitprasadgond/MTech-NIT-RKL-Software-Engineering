package cute.concolic.input;

import java.io.Serializable;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */

public class Dumbo implements Serializable {
    public final static Dumbo val = new Dumbo();

}
